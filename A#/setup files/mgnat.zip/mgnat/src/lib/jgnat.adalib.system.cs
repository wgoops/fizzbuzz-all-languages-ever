namespace mgnat.adalib.system {
}