namespace mgnat.adalib {
}