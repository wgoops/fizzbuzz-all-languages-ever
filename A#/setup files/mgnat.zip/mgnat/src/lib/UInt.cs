using System;
namespace mgnat.adalib {

#if !COMPACT
   [Serializable]
#endif
   public class UInt {
      public uint all;   
   }
}