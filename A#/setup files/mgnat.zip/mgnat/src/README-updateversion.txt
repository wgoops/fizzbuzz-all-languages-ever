To update compiler version #
1) Change gnatvsn.ads
2) cd lib, make lib