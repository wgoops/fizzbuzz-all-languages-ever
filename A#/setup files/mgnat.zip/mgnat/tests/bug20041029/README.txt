1. MGNAT and the .NET Framework SDK must be on your PATH
2. cd samples
3. nmake

This produces the bug
